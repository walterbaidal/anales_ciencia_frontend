import { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import { HomeLayout } from './layouts/HomeLayout/index.jsx';
import './App.css';

function App() {
  const [user, setUser] = useState({});

  console.log(user);

  return (
    <Routes>
      <Route path="/" element={<HomeLayout setUser={setUser} />} />
    </Routes>
  );
}

export default App;

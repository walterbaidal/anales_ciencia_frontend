import { Form, Button, Row, Col } from 'react-bootstrap';
import './index.styles.css';

export const AuthBar = ({ setUser }) => {
  const handleSubmit = async (e) => {
    e.preventDefault();

    // const response = fetch('/api/auth', {
    //   method: 'POST',
    //   headers: {
    //     'Content-Type': 'application/json',
    //     body: JSON.stringify({
    //       username: e.target[0].value,
    //       password: e.target[1].value,
    //     }),
    //   },
    // });
    // const user = await response.json();
    setUser({ username: 'test', password: '24123' });
  };

  return (
    <Col id="authbar">
      <Row>
        <Form className="d-flex" onSubmit={handleSubmit}>
          <Form.Group className="me-3" controlId="username">
            <Form.Label>Username</Form.Label>
            <Form.Control type="text" placeholder="Username" name="username" />
          </Form.Group>

          <Form.Group className="me-3" controlId="password">
            <Form.Label>Password</Form.Label>
            <Form.Control
              type="password"
              placeholder="Password"
              name="password"
            />
          </Form.Group>

          <Button variant="primary" type="submit">
            Login
          </Button>
        </Form>
      </Row>
    </Col>
  );
};

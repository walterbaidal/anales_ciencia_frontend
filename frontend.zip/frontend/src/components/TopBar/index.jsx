import './index.styles.css';

export const TopBar = () => {
  return <div id="topbar">Anales de la Ciencia</div>;
};

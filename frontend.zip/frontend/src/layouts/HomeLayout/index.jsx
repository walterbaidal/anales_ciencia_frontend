import { TopBar } from '../../components/TopBar';
import { AuthBar } from '../../components/AuthBar';
import './index.styles.css';

export const HomeLayout = ({ setUser }) => {
  return (
    <div id="home" className="container">
      <TopBar />
      <AuthBar setUser={setUser} />
      <div className="content">
        <div className="column">a</div>
        <div className="column">b</div>
        <div className="column">c</div>
      </div>
    </div>
  );
};
